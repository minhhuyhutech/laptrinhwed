﻿namespace webvuivui.Models
{
    public class sanphamcs
    {
      
    
        
            public string MaSP { get; set; }
            public string TenSP { get; set; }
            public double Gia { get; set; }
            public double GiaBan { get; set; }
            public string MoTa { get; set; }
            public string HinhAnh { get; set; }
        }
    }


