﻿using Microsoft.AspNetCore.Mvc;

namespace webvuivui.Controllers
{
    public class HomeController1 : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Message = "hello";
            ViewData[ "key"] = "hello word";
            return View();
        }
    }
}
