﻿using Microsoft.AspNetCore.Mvc;
using webvuivui.Models;

namespace webvuivui.Controllers
{
    public class Sanpham1 : Controller
    {
        public IActionResult ViewSanPham()
        {
            var sp = new sanphamcs
            {
                MaSP = "SP001",
                TenSP = "Áo thun lập trình",
                Gia = 199000,
                GiaBan = 159000,
                MoTa = "Chất liệu cotton, in hình mã code C# cực chất",
                HinhAnh = "/images/hinhanhne.jpg"
            };
           return  View(sp);
        }
        
    }
}
