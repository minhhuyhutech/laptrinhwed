﻿using Microsoft.AspNetCore.Mvc;

namespace webvuivui.Controllers
{
    public class Student : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ShowKQ(string mssv, string hoten, double diemTB, string chuyenNganh)
        {
            // Lưu thông tin vào TempData (có thể dùng ViewBag nếu không cần truyền giữa nhiều view)
            ViewBag.MSSV = mssv;
            ViewBag.HoTen = hoten;
            ViewBag.ChuyenNganh = chuyenNganh;

            // Đếm số lượng SV cùng ngành
            if (TempData["SoLuong_" + chuyenNganh] == null)
                TempData["SoLuong_" + chuyenNganh] = 1;
            else
                TempData["SoLuong_" + chuyenNganh] = (int)TempData["SoLuong_" + chuyenNganh] + 1;

            ViewBag.SoLuong = TempData["SoLuong_" + chuyenNganh];

            return View();
        }
    }
}
